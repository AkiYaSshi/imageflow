# ImageFlow is open-source software. You may modify and share it  
# under the GNU General Public License v3 or later.  
#  
# This software is provided "as is" without any warranty,  
# including merchantability or fitness for a particular purpose.  
# See the GNU General Public License for details.  



#██╗███╗░░░███╗██████╗░░█████╗░██████╗░████████╗██╗███╗░░██╗░██████╗░░░░░░░░░░
#██║████╗░████║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██║████╗░██║██╔════╝░░░░░░░░░░
#██║██╔████╔██║██████╔╝██║░░██║██████╔╝░░░██║░░░██║██╔██╗██║██║░░██╗░░░░░░░░░░
#██║██║╚██╔╝██║██╔═══╝░██║░░██║██╔══██╗░░░██║░░░██║██║╚████║██║░░╚██╗░░░░░░░░░
#██║██║░╚═╝░██║██║░░░░░╚█████╔╝██║░░██║░░░██║░░░██║██║░╚███║╚██████╔╝██╗██╗██╗
#╚═╝╚═╝░░░░░╚═╝╚═╝░░░░░░╚════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝╚═╝░░╚══╝░╚═════╝░╚═╝╚═╝╚═╝

import bpy
import numpy as np
import os
import math
import mathutils
import re


from bpy.props import StringProperty, CollectionProperty
from bpy_extras.io_utils import ImportHelper 
from bpy.types import Operator, OperatorFileListElement


class FileBrowswer(ImportHelper, Operator) : 

    bl_idname = "fb.open" 
    bl_label = "Import Sequence" 
    bl_description = "Import .png, .jpg, .jpeg, .tif, .tiff, .bmp image sequence" 

        #file format filter
    filter_glob: StringProperty( 
    default = '*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp', options={'HIDDEN'} ) 

    files: CollectionProperty(
    name = "BVH files", 
    type = OperatorFileListElement, 
    ) 
    directory: StringProperty(subtype='DIR_PATH')
    
    
    

    def execute(self, context): 
        """Do something with the selected file(s).""" 
        
        scene = context.scene
        set = scene.setting
        
        new_sequence = ImageSequence()
        
        original_frame = new_sequence.get_start_frame()
        
            #set where the arrange start
        if(set.start_mode == 'NOW'):
            
            bpy.context.scene.frame_current = original_frame
            
        elif(set.start_mode == 'BEGIN'):
        
            bpy.context.scene.frame_current = 1
            
        elif(set.start_mode == 'INPUT'):
            
            bpy.context.scene.frame_current = set.input_frame
            
            #import file and save output in ps_output
        ps_output = new_sequence.process_file(context, self.directory, self.files)
        obj = ps_output[0]
        seqPath = ps_output[1]
        
            #get  Offset of image sequence
        seqOffset = get_last_number(obj)
        print(f'the offset is {seqOffset}.')
        
            #mach end frame with image end if statement
        if(set.match_frame):
            
            new_sequence.match_keyframe_length(len(self.files) + bpy.context.scene.frame_current - 1)
        
            #auto caculate or not if statement
        if(set.is_auto_calculate == True):
            
            ce_output = cal_exposure(seqPath)
            key = ce_output[0]
            dur = ce_output[1]

            obj.select_set(True)
            
                #arg1 is ref object, 2 is number of keyframe
                #3 is the value of offset if first image is not #1
            new_sequence.single_arrange_keyframe(obj, key, seqOffset)
            
        else:
            
            obj.image_user.frame_duration = len(self.files)

            
         
            #back to frame user chosen
        bpy.context.scene.frame_current = original_frame
        
        
        return {'FINISHED'} 
    
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞▖ add popup diaolog box of import image sequence ▝▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
class WM_OT_imageSequence(bpy.types.Operator):
    bl_label = "Import Sequence" 
    bl_description = "Import .png, .jpg, .jpeg, .tif, .tiff, .bmp image sequence" 
    bl_idname = "wm.imagesequence"    
    
    def draw(self, context):
        
        scene = context.scene
        set = scene.setting
        
        layout = self.layout

        row = layout.row()
        row.alignment = 'RIGHT'
        row.scale_x = 1
        row.prop(set, "text")
        
        row = layout.row()
        col = row.column()
        col.alignment = 'RIGHT'
        col.scale_x = 2.3
        col.label(text = "Imgae Size: ")
        col = row.column()
        col.scale_x = 1
        col.prop(set, "resize")
        
        row.alignment = 'LEFT'
        row = layout.row()
        row.prop(set, "is_auto_calculate")
        
        row = layout.row()
        row.alignment = 'RIGHT'
        
        if set.is_auto_calculate == True:
            
            display_text = "Enabling this option increases execution time."
            display_icon = 'ERROR'
            
        else:
            
            display_text = ""
            display_icon = 'NONE'
        
        
        row.label(text = display_text, icon = display_icon)
        
        row = layout.row()
        row.enabled = set.is_auto_calculate
        col = row.column()
        col.alignment = 'LEFT'
        col.scale_x = 1
        col.prop(set, "start_mode")
        
        if (set.start_mode == 'INPUT'):
            print("self.start_mode is input")
            col1 = row.column()
            col1.alignment = 'RIGHT'
            col1.prop(set, "input_frame")
            
        row = layout.row()
        row.prop(set, "match_frame")
        
    def execute(self, context):
        
        bpy.ops.fb.open('INVOKE_DEFAULT')
        
        return {'FINISHED'}

    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    
class OT_ResizeImage(bpy.types.Operator):
    
    bl_label = "Resize To Screen Size"
    bl_idname = "ot.resize"
    bl_description = "Resize selected image to screen size."

    @classmethod
    
    def poll(cls, context):
        return True

    def execute(self, context):
        
        if len(bpy.context.selected_objects) == 0:
        
            self.report({'ERROR_INVALID_CONTEXT'}, "At least one image must be selected!")
        
            return {'CANCELLED'}
        
        scene = context.scene
        set = scene.setting
        
        files = list()
        scaleobj = list()
        
        objs = bpy.context.selected_objects
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in objs:
            
            if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
            
                img = obj.data
                files.append(img)
                scaleobj.append(obj)
                
            else:
                
                self.report({'WARNING'}, "Non-image objects selected will not be scaled.")

                
        directory = files[0].filepath
                
        tran = img_scale_to_somesize(directory, files, set.resize, isolate = True)

        for obj in scaleobj:
            
            obj.location = tran[0]
            obj.rotation_euler = tran[1]
            obj.scale = (1, 1, 1)
            obj.empty_display_size = tran[2]

            
        return{'FINISHED'}
    
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞▖ add panel ▝▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
class MyMainPanel(bpy.types.Panel):
    
    bl_label = "ImageFlow Panel"
    bl_idname = "PT_GPHelper"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ImageFlow'
    bl_description = "Tools for improving 2D animation making"
    

    def draw(self, context):
        
        scene = context.scene
        set = scene.setting
        obj = bpy.context.object
        
        layout = self.layout
        row = layout.row()
        
#        row.progress(factor = set.image_input_prog)
#        row = layout.row() 
#        
        row.scale_y = 1.8
        row.operator("wm.imagesequence", icon = 'FILE_IMAGE')
        
        if obj is not None:

            if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
                status = True
                
            else:
                status = False
            
            box = layout.box()
            row = box.row()
            box.enabled = status
            row.operator("ot.resize")
            row = box.row()
            
            #row.scale_x = 0.9
            row.alignment = 'CENTER'
            row.label(text = "Zoom", icon = 'VIEW_ZOOM')
            row.prop(set, "resize", icon_only = True)
            
            if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
                
                op_status = True
                box = layout.box()
                row = box.row()
                row.alignment = 'LEFT'
                row.label(text = "Image Info")
                row = box.row()
                box.enabled = status
                row.alignment = 'RIGHT'
                row.prop(obj, "use_empty_image_alpha", icon_only = True)
                col = row.column()
                if obj.use_empty_image_alpha:
                    
                    col.enabled = True
                    
                else:
                    col.enabled = False
                col.prop(obj, "color", index = 3, slider = True, text = "Opacity")    

                
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞▖ properties of import images ▝▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
class ObjInfo(bpy.types.PropertyGroup):
        
    text: bpy.props.StringProperty(
    name = "Name", 
    description = 'Name of import files',
    default = "")
    
    resize: bpy.props.FloatProperty(
    name = "Size",
    description = "Scales image to a percentage of the canvas.",
    precision = 2,
    step = 1,
    default = 1.0,
    soft_min = 0,
    soft_max = 10
    )
    
    start_mode: bpy.props.EnumProperty(
    name = "Image Start Show At",
    description = "Import image will start to arrange keyframes from",
    items = [('NOW', "Current key frame", ""),
             ('BEGIN', "Beginning", ""),
             ('INPUT', "Custom", "")
    ],
    default = 'NOW')
    
    match_frame: bpy.props.BoolProperty(
    name = "Scene frames match input images",
    description = "Sets total frames based on input images.",
    default = True)
    
    input_frame: bpy.props.IntProperty(
    name = "",
    description = "First frame of image in timeline.",
    subtype = 'TIME',
    default = 1)
    
    is_auto_calculate: bpy.props.BoolProperty(
    name = "Auto Keyframe",
    description = "Auto caculate and delete image looks same.\nIt's takes times.",
    default = True)
    
        #progress bar
    image_input_prog: bpy.props.FloatProperty(
    default = 0)
        
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞▖ seq image keyframe class object ▝▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
class ImageSequence():    
    
    def __init__(self):
        
        pass
    
        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
        #╏╠══[𝍖𝍖𝍖 𝚊𝚍𝚍 𝚜𝚎𝚕𝚎𝚌𝚝𝚎𝚍 𝚏𝚒𝚕𝚎𝚜 𝚝𝚘 𝚕𝚒𝚜𝚝, 𝚜𝚘𝚛𝚝 𝚏𝚒𝚕𝚎𝚜 𝍖𝍖𝍖]      💦
        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    def process_file(self, context, _directory, files): 
        
        scene = context.scene
        set = scene.setting
        col_name = set.text
        
        seqPath = list()
        
        tran = img_scale_to_somesize(_directory, files, set.resize)
        img_lo = tran[0]
        img_ro = (math.radians(90), 0, 0)
        size = tran[2]
        img_sc = mathutils.Vector((1, 1, 1))
          
#        import file

        for file in files:
            
            imgFullPath = os.path.join(_directory, file.name)
            seqPath.append(imgFullPath)
        
        empty = bpy.data.objects.new(files[0].name, None)
        empty.location = img_lo
        empty.rotation_euler = img_ro
        empty.empty_display_type = 'IMAGE'
        empty.empty_display_size = size
        empty.data = bpy.data.images.load(seqPath[0])
        scene.collection.objects.link(empty)
        
        self.obj = bpy.context.object
        empty.name = col_name
        img = empty.data

        img.source = 'SEQUENCE'
            
            #get reference opacity
        empty.image_user.frame_duration = 1
        empty.use_empty_image_alpha = True

        return [empty, seqPath]
    
        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
        #╏╠══[𝍖𝍖𝍖 𝚊𝚛𝚛𝚊𝚗𝚐𝚎 𝚔𝚎𝚢𝚏𝚛𝚊𝚖𝚎, 𝚘𝚗𝚕𝚢 𝚜𝚑𝚘𝚠 𝚔𝚎𝚢𝚏𝚛𝚊𝚖𝚎 𝚒𝚗 𝚍𝚞𝚛𝚊𝚝𝚒𝚘𝚗 𝍖𝍖𝍖]      💦
        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    def single_arrange_keyframe(self, obj, keys, offset):
        
        obj.select_set(True)
        bpy.context.scene.tool_settings.keyframe_type = 'KEYFRAME'
        
        print("╏╠══[𝍖𝍖𝍖 Start to arrange keyframe 𝍖𝍖𝍖]      💦")
        
        for i in range(len(keys)):
            
            obj.image_user.frame_offset = keys[i] + offset - 1
            obj.image_user.keyframe_insert("frame_offset")
            
            if i+1 < len(keys):
                duration = keys[i+1] - keys[i]
                bpy.ops.screen.frame_offset(delta = duration)
                
            #set interpolation_type to CONSTANT
        fcurves = obj.animation_data.action.fcurves
        for fcurve in fcurves:
            for kf in fcurve.keyframe_points:
                kf.interpolation = 'CONSTANT'    

        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
        #╏╠══[𝍖𝍖𝍖 𝚐𝚎𝚝 𝚝𝚑𝚎 𝚏𝚛𝚊𝚖𝚎 𝚞𝚜𝚎𝚛 𝚜𝚝𝚘𝚙ed 𝚊𝚝 𝚒𝚗𝚒𝚝𝚒𝚊𝚕𝚕𝚢 𝍖𝍖𝍖]      💦
        #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    def get_start_frame(self):
        
        cur_frame = bpy.context.scene.frame_current
        
        return cur_frame
    
    def match_keyframe_length(self, _length):
        
        bpy.context.scene.frame_end = _length
        
        
        
    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    #╏╠══[𝍖𝍖𝍖 calculate the value of duration of each image 𝍖𝍖𝍖]      💦
    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
def cal_exposure(FilesPath):
    
    scene = bpy.context.scene
    set = scene.setting
    
    image_duration = list()
    key_image_frame = list()
    
    image_duration.append(1)
    n = 0
    
    key_image_frame.append(0)
    
        #1)開始逐一比對當前圖像跟下一張圖像
    for i in range(len(FilesPath)):
        
            #2)確認下一張圖像存在
        if (i + 1) < (len(FilesPath)):
            
            now_file = FilesPath[i]
            next_file = FilesPath[i + 1]
            
                #3)兩張圖像相同
            if (compare_images(now_file, next_file)):
                
                image_duration[n] += 1
                                
                #兩張圖像不同
            else:
                
                n += 1
                key_image_frame.append(i+1)
                image_duration.append(1)
                
        print(f'完成度：{i}/{len(FilesPath)}')
        #set.image_input_prog = float(i) / len(FilesPath)
        
    bpy.ops.object.select_all(action='DESELECT')
    
    return [key_image_frame, image_duration] #關鍵張list，持續時間list

    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    #╏╠══[𝍖𝍖𝍖 𝚊𝚍𝚍 𝚊 𝚖𝚎𝚜𝚑 𝚙𝚕𝚊𝚗𝚎 𝚝𝚘 𝚖𝚎𝚊𝚜𝚞𝚛𝚎 𝚜𝚌𝚊𝚕𝚎 𝚊𝚖𝚘𝚞𝚗𝚝 𝍖𝍖𝍖]      💦
    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
def img_scale_to_somesize(_directory, files, user_input = 1, isolate = False):
    
    img_measure_path = os.path.join(_directory, files[0].name)
    filename = files[0].name
    
    if isolate == True:
        
        img_measure_path = bpy.path.abspath(_directory)
        
        split = list()
        split = os.path.split(_directory)
        
        _directory = f'{split[0]}/'
        _directory = bpy.path.abspath(_directory)
        
        filename = split[1]
        
    line = "\n\n=========================================================================\n\n"
    
    print(f'{line}the path to image is:{img_measure_path}{line}')
    print(f'{line}the directory is:{_directory}{line}')
    print(f'{line}the file name is: {files[0].name}{line}')

    bpy.ops.image.import_as_mesh_planes(
    filepath = img_measure_path, 
    files = [{"name":filename, "name":filename}], 
    directory = _directory, 
    align_axis = 'CAM', prev_align_axis='CAM_AX', size_mode='CAMERA', fill_mode='FIT')

    tmpobj = bpy.context.active_object
    
    print(f'{line}the active object now is:{tmpobj}{line}')
    
    loc = tmpobj.location
    rot = tmpobj.rotation_euler
    size = tmpobj.dimensions[0] * user_input
    tmpobj.select_set(True)
    bpy.ops.object.delete(use_global = False)

    return [loc, rot, size]



    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
    #╏╠══[𝍖𝍖𝍖 𝚌𝚘𝚖𝚙𝚊𝚛𝚎 𝚒𝚏 𝚝𝚠𝚘 𝚒𝚖𝚊𝚐𝚎𝚜 𝚒𝚍𝚎𝚗𝚝𝚒𝚌𝚊𝚕, 𝚛𝚎𝚝𝚞𝚛𝚗 𝚋𝚘𝚘𝚕𝚎𝚊𝚗 𝍖𝍖𝍖]      💦
    #𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖𝍖
def compare_images(image1_path, image2_path, tolerance=0.0001, scale_factor=0.25):
    # 使用 OpenImageIO 讀取影像
    
    import OpenImageIO as oiio
    
    image1 = oiio.ImageBuf(image1_path)
    image2 = oiio.ImageBuf(image2_path)

    # 取得影像原始尺寸
    spec1 = image1.spec()
    spec2 = image2.spec()
    
    # 若尺寸不同，則視為不同
    if (spec1.width, spec1.height) != (spec2.width, spec2.height):
        return False

    # 設定縮小後的尺寸
    new_width = int(spec1.width * scale_factor)
    new_height = int(spec1.height * scale_factor)
    
    # 創建 ROI (Region of Interest) 來指定新的影像大小
    roi = oiio.ROI(0, new_width, 0, new_height, 0, 1, 0, spec1.nchannels)
    
    # 使用 ROI 來縮小影像
    image1 = oiio.ImageBufAlgo.resize(image1, roi=roi)
    image2 = oiio.ImageBufAlgo.resize(image2, roi=roi)

    # 轉換為 NumPy 陣列
    pixels1 = np.array(image1.get_pixels(oiio.FLOAT))
    pixels2 = np.array(image2.get_pixels(oiio.FLOAT))

    # 計算差異
    diff = np.mean(np.abs(pixels1 - pixels2))

    return diff <= tolerance


    #get offset. arg: image object
def get_last_number(obj):
    """
    從檔案名稱中提取最後的數字，例如：
    - '3-1Animation03.png' → 提取 `3`
    - 'IMG_3207.png'       → 提取 `3207`
    - 'Scene_15A_100.png'  → 提取 `100`
    - 'Test_File_42.jpg'   → 提取 `42`
    - 'NoNumberHere.png'   → 沒有數字則回傳 `0`
    """

    image_path = obj.data.filepath
    filename = os.path.basename(image_path)  # 取得檔案名稱（去掉路徑）
    print(filename)

    numbers = re.findall(r"[0-9]+", filename)  # 找出所有數字
    if numbers:
        return int(numbers[-1])  # 取最後一個數字

    return 0




    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞ register and unregister ▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
classes = {ObjInfo, FileBrowswer, MyMainPanel, WM_OT_imageSequence, OT_ResizeImage}
        
def register():
    for iclass in classes:
        bpy.utils.register_class(iclass)
        
    bpy.types.Scene.setting = bpy.props.PointerProperty(type = ObjInfo)
    
def unregister():
    for iclass in classes:
        bpy.utils.unregister_class(iclass)
        
    del bpy.types.Scene.setting
        
        
        
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
    #▞▞▞▞▞ initial ▞▞▞▞▞
    #▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞▞
if __name__ == "__main__":
    register()